
import requests
import json

url = 'https://duga.market/api/v1/auth/register'
payload = {
    "phone": 79119129233,
    "first_name": "Сергей",
    "last_name": "Ровенков",
    "city": "Москва"
}
headers = {
  'Content-Type': 'application/json',
  'Accept': 'application/json'
}

response = requests.request('POST', url, headers=headers, json=payload)
response.json()